//
// Meme.swift
//  memeMe1.0
//
//  Created by macOS on 4/12/22.
//

import Foundation
import UIKit

struct Meme{
    var topText:String
    var bottomText:String
    var originalImage:UIImage
    var memedImage:UIImage
}
