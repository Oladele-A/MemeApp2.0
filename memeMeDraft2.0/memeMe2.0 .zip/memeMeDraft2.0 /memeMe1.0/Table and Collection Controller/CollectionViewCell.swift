//
//  CollectionViewCell.swift
//  memeMe1.0
//
//  Created by Oladele Abimbola on 4/25/22.
//

import Foundation
import UIKit

class CollectionViewCell: UICollectionViewCell{
    
    @IBOutlet weak var collectionCellImage: UIImageView!
}
